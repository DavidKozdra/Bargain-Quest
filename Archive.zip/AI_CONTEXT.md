# Bargain Quest — AI Project Context

> This file is gitignored. It exists to give AI assistants deep, structured context about the codebase so they can help effectively without needing to re-explore every session.

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Tech Stack & Entry Points](#2-tech-stack--entry-points)
3. [File Map](#3-file-map)
4. [Class Reference](#4-class-reference)
5. [Game State Machine](#5-game-state-machine)
6. [Economy System](#6-economy-system)
7. [Combat System](#7-combat-system)
8. [Travel & Navigation](#8-travel--navigation)
9. [NPC Systems](#9-npc-systems)
10. [Day/Night & Seasons](#10-daynight--seasons)
11. [Random Events](#11-random-events)
12. [Rendering & Sprites](#12-rendering--sprites)
13. [UI System](#13-ui-system)
14. [Save/Load System](#14-saveload-system)
15. [Progression & Books](#15-progression--books)
16. [Data Tables](#16-data-tables)
17. [Performance Notes](#17-performance-notes)
18. [Known Patterns & Conventions](#18-known-patterns--conventions)

---

## 1. Project Overview

**Bargain Quest** is a browser-based, turn-based trading strategy game built with **p5.js** and vanilla JavaScript. It is inspired by Mount & Blade but focuses on economics, trade, and negotiation rather than military conquest.

### Core Fantasy
Rise to wealth by exploiting supply/demand imbalances between cities, surviving raider threats, managing a fleet of boats, and making smart market moves — not by grinding combat.

### Win Condition
Accumulate a configurable gold target (default **5000 gold**) before running out of days (optional day limit). The player loses if they go broke or hit the day limit penniless.

### Key Pillars
| Pillar | Description |
|--------|-------------|
| Dynamic Economy | City prices shift with supply, demand, season, holidays, and NPC activity |
| Turn-Based Combat | d6-based land fights and grid-based naval battles |
| Procedural World | Perlin noise terrain with biome assignment, random city placement |
| NPC Simulation | Traders with personalities travel and trade autonomously |
| Fleet Management | Three boat types with condition-based degradation |
| Reputation | Per-city 0–100 scale that affects buy/sell prices |

---

## 2. Tech Stack & Entry Points

| Concern | Solution |
|---------|---------|
| Rendering | p5.js (canvas 2D) — loaded via CDN |
| Language | Vanilla ES6 JavaScript (no bundler) |
| Persistence | `localStorage` (single-slot save) |
| Pathfinding | Custom A* in `utils/astar.js` |
| UI | Custom HTML/CSS panels toggled via `UI_Manager.js` |
| No build step | All scripts loaded via `<script>` tags in `index.html` |

### Script Load Order (`index.html`)
The load order matters — globals must be defined before they are used:

```
preload.js → sprites.js → utils/astar.js → utils/miscMap.js
→ gameState.js → item.js → Cities.js → map.js → Boat.js
→ Trader.js → TraderManager.js → Raider.js → RaiderManager.js
→ Combat.js → EventSystem.js → player.js → dayNight.js
→ SaveSystem.js → notificationManager.js → UI_Manager.js
→ menuBackground.js → musicSystem.js → sound.js → LevelEditor.js
→ ui.js → game.js
```

`game.js` is last because it references everything. `ui.js` comes just before it because it registers UI screens that `game.js` drives.

---

## 3. File Map

```
/
├── index.html          Entry point, loads all scripts
├── game.js             Main p5.js draw/setup loop, world state, camera
├── ui.js               All UI screen definitions and event handlers (~57 KB)
├── style.css           CSS for HTML UI panels (~60 KB)
├── preload.js          p5.js preload() — loads Car.png external asset
├── favicon.svg
├── logo.png
├── image.png
│
├── classes/
│   ├── gameState.js        GameStateManager — state machine
│   ├── player.js           Player entity, inventory, fleet, movement
│   ├── item.js             Item class + ItemLibrary (18 items + 4 books)
│   ├── Cities.js           City entity — economy, population, reputation
│   ├── map.js              Procedural terrain generation (Perlin noise)
│   ├── Boat.js             Boat class + fleet helpers
│   ├── Trader.js           NPC Trader AI
│   ├── TraderManager.js    Spawns/updates all NPC traders
│   ├── Raider.js           Raider/pirate/monster entity
│   ├── RaiderManager.js    Spawns/updates all raiders and pirates
│   ├── Combat.js           Land + naval turn-based combat
│   ├── EventSystem.js      Random travel events
│   ├── dayNight.js         DayNightCycle — time, seasons, day counter
│   ├── UI_Manager.js       Screen registry and visibility management
│   ├── notificationManager.js  Toast notification queue
│   ├── SaveSystem.js       Serialize/deserialize game state to localStorage
│   ├── sprites.js          Procedural p5.js sprite generation (~1000 lines)
│   ├── LevelEditor.js      Map editing tools (in-progress feature)
│   ├── menuBackground.js   Animated main menu background
│   ├── musicSystem.js      Background music management
│   └── sound.js            Sound effect management
│
└── utils/
    ├── astar.js            A* pathfinding (binary heap, typed arrays)
    └── miscMap.js          Map utility helpers
```

---

## 4. Class Reference

### `GameStateManager` (`classes/gameState.js`)

Central state machine. All game logic branches on the current state.

```javascript
// States
'MAIN_MENU' | 'NEW_GAME_CONFIG' | 'PLAYING' | 'COMBAT' |
'INVENTORY' | 'PAUSED' | 'RANDOM_EVENT' | 'WEEKLY_SUMMARY' |
'SETTINGS' | 'GAMEWON' | 'GAMELOSE'

gameState.setState('COMBAT')
gameState.is('PLAYING')        // boolean
gameState.onChange(cb)         // subscribe to transitions
```

Allowed transitions are defined as a map with wildcard (`'*'`) support.

---

### `Player` (`classes/player.js`)

The player-controlled entity. Lives in `window.player` globally.

| Property | Type | Description |
|----------|------|-------------|
| `x, y` | int | Grid tile position |
| `gold` | number | Current gold |
| `inventory` | `Map<string, {item, quantity}>` | Items carried |
| `party` | Array | Party members (max 4) |
| `fleet` | `Boat[]` | All owned boats |
| `activeBoat` | `Boat\|null` | Currently used vessel |
| `isSailing` | bool | On water |
| `cargoCapacity` | number | Base 50 + boat bonuses |
| `weeklyIncome` | number | Tracked for weekly summary |
| `weeklySpending` | number | Tracked for weekly summary |
| `modifiers` | object | Permanent bonuses from books |

**Key modifiers** (from book system):
- `negotiationDiscount` — reduces buy price by 5%
- `bribeCostReduction` — reduces bribe cost by 15%
- `bribeCooldownBonus` — adds 2 days to bribe cooldown window
- `pricesRevealed` — Market Analysis book
- `holidaysRevealed` — Holidays Almanac book

**Key methods:**
```javascript
player.move(dx, dy)               // direct tile movement
player.setPathTo(x, y)            // A* click-to-move
player.addItem(item, quantity)    // inventory add (checks cargo)
player.removeItem(name, qty)      // inventory remove
player.update()                   // called each frame, drives pathfinding
```

**Event: `dayChanged`** — Player listens for this to consume food, check starvation.

---

### `Item` / `ItemLibrary` (`classes/item.js`)

```javascript
new Item({
  name: 'Wheat',
  baseValue: 10,
  weight: 2,
  category: 'food',     // 'food' | 'raw' | 'crafted' | 'luxury' | 'book'
  rarity: 1.0,          // price multiplier
  seasonality: ['Fall'], // seasons where price is +25%
  perishable: true,
  tradable: true
})
```

`ItemLibrary` is a static registry. Access via `ItemLibrary.get('Wheat')`.

**`item.getValue(city, player)`** — dynamic price calculation:
1. Start with `baseValue × rarity`
2. Apply season bonus (+25% if matching)
3. Apply city demand factor (city population vs inventory)
4. Apply supply factor (inverse of city stock)
5. Apply distance factor (optional)
6. Apply holiday boost (+50% on matching holiday days)
7. Apply book holiday discount (−30% with Holidays Almanac)
8. Apply reputation modifier (±8% based on city reputation 0–100)
9. Apply negotiation modifier (±5% with Negotiation book)

---

### `City` (`classes/Cities.js`)

Cities are placed at creation time and stored in `window.cities[]`. Each has a unique name.

| Property | Type | Notes |
|----------|------|-------|
| `name` | string | Unique |
| `x, y` | int | Grid tile |
| `population` | number | Affects demand |
| `inventory` | `Map<string, number>` | City stock levels |
| `holidays` | `Array<{name, item, day, season, discount}>` | |
| `reputation` | number | 0–100, starts 50 |
| `productionRecipes` | Array | Crafting recipes |
| `isPort` | bool | Enables sailing access |

**Key methods:**
```javascript
city.calculateItemPrice(itemName, player)  // full dynamic price
city.growPopulation()                      // food-based growth
city.runProduction()                       // crafts goods from inputs
city.adjustReputation(delta)               // ±rep, affects prices
```

**Production recipes** (run on each day tick):
- `Wheat → Bread` (5 wheat → 3 bread)
- `Iron + Wood → Tools`
- `Clay → Pottery`
- `Fish + Salt → SaltedFish`
- `Herbs + Clay → Wine` (approximate)
- `Stone + Iron → Jewelry`

**Reputation decay:** −0.15/day toward neutral (35), manual boosts from player defeating nearby raiders.

---

### `Boat` (`classes/Boat.js`)

```javascript
// Types
'rowboat'  // 200g,  fastest, tiny cargo
'sloop'    // 600g,  medium
'galleon'  // 1500g, slowest, massive cargo
```

| Stat | rowboat | sloop | galleon |
|------|---------|-------|---------|
| Cost | 200g | 600g | 1500g |
| Speed (ms/tile) | 180 | 120 | 90 |
| Cargo bonus | +10 | +25 | +50 |
| HP | 3 | 5 | 8 |
| Attack | 1 | 2 | 3 |
| Naval grid size | 1 cell | 2 cells | 3 cells |

All stats **degrade linearly** with `condition` (0–100%). A boat at 50% condition has ~50% effective stats.

**Repair cost:** `(100 - condition) × multiplier`. With Wood in city: normal cost. Without: 2.5× premium.

**Sinking:** `condition = 0` → boat destroyed, removed from fleet.

---

### `Trader` (`classes/Trader.js`)

NPC traders travel autonomously between cities, trading goods.

**Personalities:**
| Personality | Buy Margin | Behavior |
|-------------|-----------|---------|
| `greedy` | 1.2× | Buys aggressively, higher risk |
| `cautious` | 1.5× | Only buys at clear profit |
| `balanced` | 1.3× | Middle ground |

**State machine:** `trading → traveling → idle → trading`

**Trade logic:**
1. At city: sell everything at current price
2. Score all items at all destination cities by `(sellPrice − buyPrice) / distance`
3. Pick best destination
4. Buy profitable items (up to 10 qty each, cargo permitting)
5. Path to destination via A*

34 unique trader names are available; uniqueness is guaranteed on spawn.

---

### `Raider` (`classes/Raider.js`)

Hostile entities that patrol and attack. Both land-based and pirate variants.

| Type | Land/Sea | Special Ability |
|------|---------|----------------|
| `bandit` | land | — |
| `marauder` | land | — |
| `raider` | land | — |
| `boss` | land | `command` (buffs nearby raiders) |
| `scout` | land | `ambush` (first-turn bonus) |
| `dragon` | land | `fire` (AoE every 2 turns) |
| `blackKnight` | land | `armor` (damage reduction) |
| `wraith` | land | `phase` (30% dodge chance) |
| pirate (`isPirate: true`) | water | Has boat, triggers naval combat |

**Detection radius:** 4–5 tiles for normal, wider for monsters. When player enters radius → chase. Adjacent → combat trigger.

**Bribe cooldown:** After bribe, raider won't attack for N days. Conflict Resolution book extends window.

---

### `CombatSystem` (`classes/Combat.js`)

Handles both land and naval encounters. Lives in `window.combatSystem`.

#### Land Combat Flow
```
1. Raider enters detection radius
2. combatSystem.startCombat(raider) called
3. gameState → 'COMBAT'
4. Loop:
   a. Player picks: Fight | Flee | Bribe
   b. Fight: player roll (d6 + attack) vs enemy roll (d6 + attack)
   c. Crit check, terrain bonus, special ability resolution
   d. HP update, check win/lose
5. combatSystem.endCombat(outcome)
6. gameState → 'PLAYING'
```

**Player attack stat:** `3 + party.length + weapon.damage + tools bonus`

**Terrain modifiers:**
| Terrain | DEF modifier |
|---------|------------|
| Forest | +1 |
| Rock | +2 |
| Sand | −1 |
| Grass | 0 |
| Snow | 0 |

**Flee chance:** 25–65% based on terrain (Forest hardest, Grass easiest).

**Bribe cost formula:** `(15 + 15 × strengthFactor) × (1 − bribeCostReduction)` gold.

#### Naval Combat Flow
```
1. Pirate enters detection, both are sailing
2. combatSystem.startNavalCombat(pirate) called
3. 5×5 grid displayed
4. Loop (NAVAL_TICK_MS = 2400ms intervals):
   a. Enemy telegraphs target cell (shown as warning)
   b. 800ms delay, then enemy fires
   c. Player can move ship (WASD) or fire by clicking grid cell
   d. Breach detection (near misses ±1 cell)
   e. HP update, condition damage on hit
5. Win/lose outcome
```

**Enemy accuracy:**
| Boat | Accuracy |
|------|---------|
| rowboat | 15% |
| sloop | 25% |
| galleon | 35% |

**Enemy maneuvering chance (post-fire):**
| Boat | Chance |
|------|--------|
| rowboat | 70% |
| sloop | 50% |
| galleon | 30% |

---

### `DayNightCycle` (`classes/dayNight.js`)

```javascript
dayNight.timeOfDay    // 0 to 2π radians
dayNight.daysElapsed  // total days since game start
dayNight.season       // 'Winter' | 'Spring' | 'Summer' | 'Fall'
```

- Full day cycle: **120 seconds** real time (`CYCLEVALUE = 120`)
- Season length: **25 days** (100-day year)
- Day change fires `CustomEvent('dayChanged')` — all systems subscribe to this

**Auto-save:** every 5 days.

**Sky rendering:** `dayNight.renderOverlay()` blends a dark alpha tint at night.

---

### `EventSystem` (`classes/EventSystem.js`)

Random events triggered during travel.

- **Trigger condition:** Every 20 tiles moved, ~10% chance
- **Timeout:** 20 seconds. Auto-resolves to worst outcome if player ignores
- **Events filtered** by terrain and season

**Known event types:**
- Broken Wheel: pay 15g to fix, or DIY (50% success chance, fail = lose item)
- Wandering Merchant: buy items or trade
- (More exist in full EventSystem implementation)

---

### `RaiderManager` / `TraderManager`

**RaiderManager:**
- Spawns land raiders every 40 days
- 30% chance to prowl near a single city
- Pirates spawn at 10% daily chance if below cap
- Monster spawn chances: dragon 2%, blackKnight 1.5%, wraith 1.5%
- Raiders intercept NPC traders and steal their cargo

**TraderManager:**
- 1–2 traders per city on game start
- Respawns dead traders every 15 days
- Per-city trader cache (for city UI display)
- Max 34 named traders; names enforced unique

---

## 5. Game State Machine

```
MAIN_MENU
  └─► NEW_GAME_CONFIG
        └─► PLAYING
              ├─► COMBAT ──────────────────► PLAYING
              ├─► INVENTORY ───────────────► PLAYING
              ├─► PAUSED ──────────────────► PLAYING
              ├─► RANDOM_EVENT ────────────► PLAYING
              ├─► WEEKLY_SUMMARY ──────────► PLAYING
              ├─► SETTINGS ────────────────► PLAYING
              ├─► GAMEWON
              └─► GAMELOSE
```

All UI screens are shown/hidden based on active state via `UIManager`.

---

## 6. Economy System

### Price Calculation Pipeline

```
baseValue × rarity
  × season bonus (×1.25 if current season matches item.seasonality)
  × demand factor (city population / baseline, inversely proportional to stock)
  × supply factor (1 / stockLevel, clamped)
  × distance factor (optional, increases with travel distance)
  × holiday boost (×1.5 on matching holiday day/item)
  × book discount (×0.7 on holidays with Holidays Almanac)
  × reputation modifier (±8% scaled on 0–100 rep)
  × negotiation modifier (±5% with Negotiation book)
```

### Supply & Demand
- Cities have finite inventory. Buying reduces stock → raises future price.
- Cities produce crafted goods from raw materials daily (production recipes).
- NPC traders buy low, travel, sell high — dynamically redistributing supply.

### Weekly Costs (every 7 days)
| Cost | Formula |
|------|---------|
| Tax | 5% of current gold |
| Port maintenance | 2% of each boat's base cost + 0.5g per extra cargo unit |
| Boat wear | −2 condition per boat |

### Reputation Effects
| Rep Range | Effect |
|-----------|--------|
| 75–100 | −8% buy price, +8% sell price |
| 50–74 | Neutral |
| 25–49 | +8% buy price, −8% sell price |
| 0–24 | Max penalty |

Reputation decays −0.15/day toward 35 (neutral). Defeating a raider near a city grants +3 rep to that city.

---

## 7. Combat System

### Weapons
| Weapon | Damage | Crit % | Notes |
|--------|--------|--------|-------|
| Fists | 0 | 5% | Default |
| Dagger | 1 | 10% | |
| Sword | 2 | 15% | |
| Axe | 3 | 20% | |
| Bow | 2 | 15% | Ranged |
| Crossbow | 3 | 25% | Ranged |
| Staff | 2 | 10% | Magic |

### Combat Outcomes
| Outcome | Player Effect | Raider Effect |
|---------|--------------|---------------|
| Win | +loot (gold + items) | Removed from map |
| Lose | −10–30% gold, −1–2 items, pushed 3 tiles | Stays |
| Fled | −1 item | Stunned 5s |
| Bribed | −gold (15–30 × strength) | Pushed 4 tiles, cooldown N days |

### Special Raider Abilities
| Ability | Effect |
|---------|--------|
| `ambush` | +3 attack on turn 1 only |
| `rage` | Stacks +1 attack each turn |
| `shield` | Blocks first hit |
| `command` | Buffs nearby raiders |
| `strike` | High-damage single attack |
| `fire` | Dragon: AoE every 2 turns |
| `armor` | Black Knight: damage reduction |
| `phase` | Wraith: 30% dodge chance |

---

## 8. Travel & Navigation

### Movement
- **Click-to-move:** Player clicks tile → A* path calculated → player follows path
- **WASD:** Direct movement (1 tile per input, but mainly used in naval combat to move ship)
- **Tile speed:** 100ms/tile land, varies by boat (90–180ms/tile sailing)

### Terrain Movement Costs (A* weights)
| Terrain | Cost |
|---------|------|
| Grass | 1 |
| Sand | 2 |
| Snow | 4 |
| Forest | 3 |
| Rock | 6 |
| Water | 5 (boat required) |

### Water Access
- Player can only enter water within **2 tiles** of a **port city**
- `isPort` flag on City enables this
- Deep water is impassable without a boat

### Speed Controls
- `SPEED_STEPS = [0.25, 0.5, 1, 2, 4]` — game speed multiplier
- Q/E keys cycle through speeds
- Speed affects day cycle rate and movement intervals

---

## 9. NPC Systems

### Trader Behavior Loop
```
1. Arrive at city
2. Sell all carried goods at city prices
3. Score all items × all destination cities by profit/distance
4. Pick best destination
5. Buy up to 10 qty of profitable items (margin > personality threshold)
6. A* path to destination
7. Repeat
```

### Raider Behavior Loop
```
1. Patrol: follow patrol waypoints between cities
2. If player in detection radius (4–7 tiles): switch to chase
3. Chase: recalculate A* path to player (30% repath chance/frame)
4. If adjacent to player: trigger combat
5. Post-combat: stun timer, resume patrol
```

### Pirate Behavior
- Same as raider but `waterOnly = true` on A* calls
- If player is sailing and pirate is adjacent → naval combat
- If player leaves water → pirate cannot follow

---

## 10. Day/Night & Seasons

### Season Schedule
| Season | Days | Item Bonuses |
|--------|------|-------------|
| Spring | 1–25 | Wheat, Herbs, Fish |
| Summer | 26–50 | Spices, Silk, Wine |
| Fall | 51–75 | Wheat, Fur, SaltedFish |
| Winter | 76–100 | Fur, Wood, Salt |

### Daily Tick (`dayChanged` event)
All systems subscribe to `CustomEvent('dayChanged')`:
1. Player: consume food per party member, check starvation
2. Cities: grow population (food-based), run production recipes
3. Raiders: decrement bribe cooldowns; respawn if below minimum
4. Traders: respawn if below minimum
5. Pirates: 10% chance to spawn new pirate if below cap
6. SaveSystem: auto-save every 5 days

---

## 11. Random Events

Events fire **every 20 tiles moved**, **~10% chance**. They present the player with a timed choice (20-second timeout).

| Event | Choices | Outcome |
|-------|---------|---------|
| Broken Wheel | Pay 15g \| DIY | Fix instantly \| 50% lose item |
| Wandering Merchant | Buy \| Trade | Item available \| barter option |

**Timeout behavior:** If player doesn't respond in 20 seconds, auto-resolves to the worst choice.

Events are filtered by:
- Current terrain type
- Current season

---

## 12. Rendering & Sprites

### Map Rendering
- All terrain drawn once to **offscreen p5.Graphics buffer** on map load
- Buffer is blitted each frame (O(1) instead of O(tiles))
- Disabled for maps > 16,000 pixels wide (memory concern)

### Camera System
```javascript
camX, camY         // viewport offset
zoom               // 0.25 to 4.0
CAM_LERP = 0.1    // smooth follow speed
```

### Viewport Culling
- Entities more than **64 pixels** outside viewport skip rendering
- AI update throttle: entities beyond **80 tiles** from player update every **8 frames**

### Procedural Sprites (`classes/sprites.js`, ~1000 lines)
All graphics are generated at startup using p5.js `createGraphics()`. **No external sprite sheets** (except Car.png).

| Sprite | Directions | Frames |
|--------|-----------|--------|
| Player | 8 | 3 (walk cycle) |
| Trader | 8 | 3 |
| Raider | 4 | 3 |
| Dragon | 4 | 3 |
| Black Knight | 4 | 3 |
| Wraith | 4 | 3 |
| Rowboat | 4 | 3 |
| Sloop | 4 | 3 |
| Galleon | 4 | 3 |
| Terrain tiles | — | 1 each |
| Decorations | — | 2–4 variants |

**Terrain decorations** are placed per-biome at map gen time (bushes, trees, rocks, lilies, seaweed, snowdrifts) and stored in the map buffer.

---

## 13. UI System

### Architecture
- HTML/CSS panels positioned over the p5.js canvas
- `UIManager` (`classes/UI_Manager.js`) tracks all screens by name
- Each screen has `create()`, `show()`, `hide()`, `update()` callbacks
- Screens show/hide based on `gameState` transitions

### Registered Screens
| Screen | State |
|--------|-------|
| `MainMenuScreen` | MAIN_MENU |
| `NewGameConfigScreen` | NEW_GAME_CONFIG |
| `SettingsScreen` | SETTINGS |
| `HUDScreen` | PLAYING (always visible) |
| `InventoryScreen` | INVENTORY |
| `PausedScreen` | PAUSED |
| `CombatScreen` | COMBAT |
| `RandomEventScreen` | RANDOM_EVENT |
| `GameLoseScreen` | GAMELOSE |
| `GameWonScreen` | GAMEWON |
| `LevelEditorScreen` | (dev tool) |

### HUD (always visible during PLAYING)
- **Top bar:** city name, time of day, season, day #, gold, FPS
- **Speed label:** current speed multiplier
- **Minimap:** viewport footprint + city/trader/raider dots
- **Notifications:** center-top toast, auto-dismiss via `NotificationManager`

### Keyboard Bindings (rebindable via Settings)
| Key | Action |
|-----|--------|
| WASD / Arrows | Movement (or naval ship movement) |
| Q / E | Game speed down / up |
| Z / X or +/- | Zoom in / out |
| R | Reset zoom |
| I | Open inventory |
| Esc | Pause / back |

---

## 14. Save/Load System

**Storage:** `localStorage` key `bargainquest_save`
**Version:** 4 (version checked on load; incompatible versions rejected)
**Slots:** Single slot only

### Serialized State
```json
{
  "version": 4,
  "timestamp": 1700000000000,
  "mapSeed": 12345,
  "cols": 150,
  "rows": 150,
  "landmass": 1,
  "gameSpeed": 2,
  "player": {
    "x": 42, "y": 37,
    "gold": 1500,
    "inventory": [["Wheat", 10], ["Iron", 5]],
    "party": [],
    "fleet": [{"type": "sloop", "name": "Sea Hawk", "condition": 85}],
    "activeBoatIndex": 0,
    "modifiers": {
      "negotiationDiscount": 0,
      "bribeCostReduction": 0,
      "bribeCooldownBonus": 0,
      "pricesRevealed": false,
      "holidaysRevealed": false
    }
  },
  "dayNight": { "timeOfDay": 3.14, "daysElapsed": 22 },
  "cities": [...],
  "traders": [...],
  "raiders": [...],
  "events": {}
}
```

**Auto-save:** every 5 in-game days.
**Manual save:** available from pause menu.

---

## 15. Progression & Books

Books are special items (category `'book'`) found in specific cities. Each book gives a **permanent passive bonus** to the player when acquired. Only one of each exists per game.

| Book | Gold Cost Threshold | Effect |
|------|-------------------|--------|
| Market Analysis | 15% of gold target | Reveals all city prices on the map |
| Holidays Almanac | 20% | Shows all city holidays; −30% discount on holiday purchases |
| Negotiation for Dummies | 50% | −5% buy price, +5% sell price permanently |
| Conflict Resolution | 10% | −15% bribe cost, +2 days bribe cooldown window |

Books are consumed on use (removed from inventory, modifier applied to `player.modifiers`).

### Party Members
- Found in cities or via events
- Increase player combat strength (+1 attack per member)
- Max 4 party members
- Each consumes 1 food per day

### Fleet Expansion
- Boats purchased at **port cities**
- Multiple boats can be owned; only `activeBoat` is used for sailing
- Non-active boats still incur weekly maintenance cost

---

## 16. Data Tables

### Full Item List
| Name | Base Value | Weight | Category | Seasonal | Perishable |
|------|-----------|--------|----------|----------|-----------|
| Wheat | 10 | 2 | food | Fall | true |
| Fish | 12 | 1 | food | Spring | true |
| Bread | 18 | 1 | food | — | true |
| SaltedFish | 20 | 1 | food | Fall | false |
| Iron | 25 | 5 | raw | — | false |
| Clay | 8 | 3 | raw | — | false |
| Wood | 15 | 4 | raw | — | false |
| Stone | 12 | 6 | raw | — | false |
| Salt | 14 | 2 | raw | Winter | false |
| Herbs | 20 | 1 | raw | Spring | false |
| Fur | 30 | 2 | raw | Winter | false |
| Tools | 40 | 3 | crafted | — | false |
| Pottery | 22 | 3 | crafted | — | false |
| Jewelry | 80 | 1 | luxury | — | false |
| Spices | 60 | 1 | luxury | Summer | false |
| Wine | 45 | 2 | luxury | Summer | false |
| Silk | 70 | 1 | luxury | Summer | false |

### New Game Configuration Globals
| Variable | Default | Description |
|----------|---------|-------------|
| `_newGameMapCols` | 150 | Map width in tiles |
| `_newGameMapRows` | 150 | Map height in tiles |
| `_newGameEventChance` | 0.10 | Random event probability |
| `_newGameRaiderInterval` | 60 | Days between raider spawns |
| `_newGameLandmass` | 1 | 0=islands, 1=normal, 2=continents |
| `_newGameGoldTarget` | 5000 | Win condition gold amount |
| `_newGameDayLimit` | 0 | Optional day limit (0 = none) |
| `_newGameCustomMap` | null | Override map data (Level Editor) |

---

## 17. Performance Notes

| Optimization | Location | Description |
|-------------|----------|-------------|
| Map buffer | `game.js` | Terrain drawn once to offscreen canvas |
| Typed A* arrays | `utils/astar.js` | Pre-allocated buffers + generation counter |
| Viewport culling | `game.js` draw loop | Entities >64px off-screen skip render |
| AI throttling | `RaiderManager`, `TraderManager` | Entities >80 tiles away update every 8 frames |
| City location map | `game.js` | `Map<"x,y", city>` for O(1) city-on-tile lookup |
| Combat cooldown | `Combat.js` | 2-second freeze prevents instant re-trigger |
| Trader per-city cache | `TraderManager` | Pre-computed trader lists per city for UI |

The game targets smooth 60fps on a standard laptop. Map sizes beyond 200×200 may cause initial generation lag.

---

## 18. Known Patterns & Conventions

### Global Variables
Key singletons are `window`-scoped:
```javascript
window.player          // Player instance
window.cities          // City[]
window.gameState       // GameStateManager
window.combatSystem    // CombatSystem
window.dayNight        // DayNightCycle
window.traderManager   // TraderManager
window.raiderManager   // RaiderManager
window.eventSystem     // EventSystem
window.uiManager       // UIManager
window.saveSystem      // SaveSystem
window.notificationManager  // NotificationManager
window.itemLibrary     // ItemLibrary
```

### Event Bus
Day change uses native `CustomEvent`:
```javascript
// Fire
window.dispatchEvent(new CustomEvent('dayChanged', { detail: { day: daysElapsed }}))

// Subscribe (in class constructor)
window.addEventListener('dayChanged', (e) => this.onDayChanged(e.detail))
```

### Adding a New Item
1. Add entry to `ItemLibrary` in `classes/item.js`
2. Optionally add to a city's starting inventory in `Cities.js`
3. Optionally add production recipe in `Cities.js`
4. Item will automatically appear in UI, trading, and save system

### Adding a New City
Cities are procedurally placed via `map.js` on new game. To add a named city:
1. The placement algorithm in `map.js` places cities based on terrain scoring
2. Names are pulled from a hardcoded array in `map.js`
3. City properties (port, holidays, recipes) are assigned at creation time

### Adding a New Raider Type
1. Add type string and `specialAbility` to `Raider.js` constructor options
2. Implement ability logic in `Combat.js` `applySpecialAbility()` method
3. Add spawn chance in `RaiderManager.js`
4. Add sprite generation in `sprites.js`

### Adding a New Event
1. Add event definition object to `EventSystem.js` events array
2. Define: `{ name, description, terrain?, season?, choices: [{label, action, result}] }`
3. `action` is a function called with `(player, game)` context

### Coding Style
- ES6 classes throughout
- No TypeScript, no bundler, no transpilation
- `snake_case` rarely used — prefer `camelCase` for all identifiers
- Comments are sparse; logic should be self-explanatory
- UI events use `addEventListener` on DOM elements created in `ui.js`
- No framework — raw DOM manipulation in `ui.js`

---

*Last updated: auto-generated from full codebase exploration. Update this file when major systems change.*
